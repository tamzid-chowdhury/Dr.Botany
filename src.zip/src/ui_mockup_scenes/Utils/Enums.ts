export enum UIEvents {
	PLAY_GAME = "PLAY_GAME",
	CONTROLS = "CONTROLS",
	ABOUT = "ABOUT",
	MENU = "MENU",
	HIDE_LAYER = 'HIDE_LAYER',
	TRANSITION_SPLASH_SCREEN = 'TRANSITION_SPLASH_SCREEN',
	SHOW_MAIN_MENU = 'SHOW_MAIN_MENU',
	SHOW_MAIN_MENU_FINISHED = 'SHOW_MAIN_MENU_FINISHED',
	FIRST_RENDER = 'FIRST_RENDER',

	CLICKED_RESUME = 'CLICKED_RESUME',
	CLICKED_START = 'CLICKED_START',
	CLICKED_LEVEL_SELECT = 'CLICKED_LEVEL_SELECT',
	CLICKED_CONTROLS = 'CLICKED_CONTROLS', 
	CLICKED_OPTIONS = 'CLICKED_OPTIONS',
	CLICKED_HELP = 'CLICKED_HELP',
	CLICKED_QUIT = "CLICKED_QUIT"
}

export enum WindowEvents {
	RESIZED = 'RESIZED'

} 

export enum UILayers {
	MAIN_MENU = "mainMenu",
	BACKGROUND = "background",
	SPLASH_SCREEN = "splashScreen",
	CONTROLS = "controls",
	LEVEL_SELECT = "levelSelect",
	OPTIONS = "options",
	HELP = "help",
	CURSOR = "Cursor",
	INGAMEUILAYER = "InGameUILayer",
	PAUSE_SCREEN = "PAUSE_SCREEN"
}

export enum InGameUILayers {
	HEALTH_BAR = "HEALTH_BAR",
	GROWTH_BAR = "GROWTH_BAR",
	MOOD_BAR = "MOOD_BAR",
	WEAPONS_INVENTORY = "WEAPONS_INVENTORY",
	ITEMS_INVENTORY = "ITEMS_INVENTORY"
}

export enum ButtonNames {
	START = "Start",
	LEVEL_SELECT = "Level Select",
	CONTROLS = "Controls",
	OPTIONS = "Options",
	HELP = "Help"
}

export enum PauseButtonNames {
	RESUME = "Resume",
	CONTROLS = "Controls",
	OPTIONS = "Options",
	QUIT = "Quit"
}